from pathlib import Path
import base64

root = Path('/home/ubuntu/capivara_tarot_prototipo')
html_path = root / 'index.html'
img_path = root / 'referencia/capivara_original.webp'
html = html_path.read_text(encoding='utf-8')
data = base64.b64encode(img_path.read_bytes()).decode('ascii')
old = 'src="referencia/capivara_original.webp"'
new = f'src="data:image/webp;base64,{data}"'
if old not in html:
    raise SystemExit('Referência de imagem não encontrada no HTML')
html = html.replace(old, new, 1)
html_path.write_text(html, encoding='utf-8')
print(f'Imagem embutida no HTML: {len(data)} caracteres base64')

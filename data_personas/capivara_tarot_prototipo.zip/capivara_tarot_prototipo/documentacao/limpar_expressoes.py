from pathlib import Path
from PIL import Image
import numpy as np
from collections import deque

folder = Path('/home/ubuntu/capivara_tarot_prototipo/expressoes')
for path in sorted(folder.glob('*.png')):
    im = Image.open(path).convert('RGBA')
    arr = np.array(im)
    alpha = arr[:, :, 3]
    # Componentes de pixels visíveis; linhas soltas ficam em componentes separados.
    active = alpha > 18
    h, w = active.shape
    seen = np.zeros((h, w), bool)
    best = []
    for y in range(h):
        for x in range(w):
            if not active[y, x] or seen[y, x]: continue
            q = deque([(y, x)]); seen[y, x] = True; comp = []
            while q:
                cy, cx = q.popleft(); comp.append((cy, cx))
                for dy, dx in ((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)):
                    ny, nx = cy+dy, cx+dx
                    if 0 <= ny < h and 0 <= nx < w and active[ny, nx] and not seen[ny, nx]:
                        seen[ny, nx] = True; q.append((ny, nx))
            if len(comp) > len(best): best = comp
    keep = np.zeros((h, w), np.uint8)
    for y, x in best: keep[y, x] = 255
    # Mantém alfa original dentro da silhueta e elimina tudo fora dela.
    arr[:, :, 3] = np.where(keep > 0, alpha, 0)
    Image.fromarray(arr).save(path, 'PNG', optimize=True)
    print(path.name, 'kept_pixels=', len(best))

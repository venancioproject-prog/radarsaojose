from PIL import Image
from pathlib import Path

src = Path('/home/ubuntu/capivara_tarot_prototipo/referencia/capivara_original.webp')
out = Path('/home/ubuntu/capivara_tarot_prototipo/referencia/capivara_referencia_9x16.webp')
img = Image.open(src).convert('RGBA')
w, h = img.size
target_h = round(w * 16 / 9)
top = max(0, (h - target_h) // 2)
if target_h > h:
    raise ValueError('Imagem não é alta o suficiente para recorte 9:16')
cropped = img.crop((0, top, w, top + target_h))
cropped.save(out, 'WEBP', lossless=True)
print(out, cropped.size)

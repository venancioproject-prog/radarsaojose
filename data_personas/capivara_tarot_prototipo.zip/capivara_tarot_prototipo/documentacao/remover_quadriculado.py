from pathlib import Path
from PIL import Image, ImageFilter
import numpy as np

root = Path('/home/ubuntu/capivara_tarot_prototipo')
src = root / 'referencia/capivara_original.webp'
out = root / 'referencia/capivara_sem_fundo.png'
rgb = np.array(Image.open(src).convert('RGB'))
mx = rgb.max(axis=2).astype(np.int16)
mn = rgb.min(axis=2).astype(np.int16)
# O quadriculado é neutro (canais quase iguais) e claro/cinza; remover todos esses pixels
# evita que um pedaço isolado permaneça dentro do contorno da cauda.
background = (mx - mn <= 22) & (mx >= 145)
alpha = np.where(background, 0, 255).astype(np.uint8)
alpha_img = Image.fromarray(alpha, 'L').filter(ImageFilter.GaussianBlur(radius=0.7))
rgba = Image.fromarray(rgb, 'RGB').convert('RGBA')
rgba.putalpha(alpha_img)
rgba.save(out, 'PNG', optimize=True)
print(out, rgba.size, 'alpha_extrema=', alpha_img.getextrema(), 'transparent_pixels=', int((np.array(alpha_img) == 0).sum()))

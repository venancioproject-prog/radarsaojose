from pathlib import Path
import base64
import re

root = Path('/home/ubuntu/capivara_tarot_prototipo')
html_path = root / 'index.html'
img_path = root / 'referencia/capivara_sem_fundo.png'
html = html_path.read_text(encoding='utf-8')
data = base64.b64encode(img_path.read_bytes()).decode('ascii')
html = re.sub(r'src="data:image/[^;]+;base64,[^"]+"', f'src="data:image/png;base64,{data}"', html, count=1)
html = html.replace('alt="Capivara oráculo"', 'alt="Capivara oráculo sem fundo"')
html_path.write_text(html, encoding='utf-8')
print(f'Protótipo atualizado com PNG transparente: {len(data)} caracteres base64')
